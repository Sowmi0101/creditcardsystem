package com.capg55.creditcardsystem.controller;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.capg55.creditcardsystem.model.Admin;
import com.capg55.creditcardsystem.service.AdminService;

@ExtendWith(MockitoExtension.class)
public class AdminControllerTest {

	@InjectMocks
	AdminController adminController;

	@Mock
	AdminService adminService;

	@Test
	void getAllAdminsTest() {
		ArrayList<Admin> admins = createAdminsEntityMockData();
		when(adminService.getAllAdmins()).thenReturn(admins);

		List<Admin> adminList = adminService.getAllAdmins();

		assert (admins.size() == adminList.size());
	}

	@Test
	void getAdminByIdTest() {

		int id = 1;
		Admin admin = createAdminEntityMockData();
		ResponseEntity<Admin> msg = new ResponseEntity<>(admin, HttpStatus.OK);
		when(adminService.getAdminById(id)).thenReturn(admin);

		ResponseEntity<Admin> admins = adminController.getAdminById(id);

		assert (admins.equals(msg));

	}

	@Test
	void saveAdminTest() {

		Admin admin = createAdminEntityMockData();
		ResponseEntity<String> msg = new ResponseEntity<String>("Admin added successfully:" + admin.getAdminId(),
				HttpStatus.OK);

		when(adminService.saveAdmin(admin)).thenReturn(admin);

		ResponseEntity<String> adminInfo = adminController.addAdmin(admin);
		assert (adminInfo.equals(msg));

	}

	private Admin createAdminEntityMockData() {

		Admin admin = new Admin();

		admin.setAdminId(1);
		admin.setfName("raju");
		admin.setlName("vinod");
		admin.setEmail("raju@gmail.com");
		admin.setuName("raju1");
		admin.setPass("vinod");
		admin.setPhoneNo(9876543210l);

		return admin;
	}

	private ArrayList<Admin> createAdminsEntityMockData() {
		ArrayList<Admin> admins = new ArrayList<>();

		Admin admin = new Admin();

		admin.setAdminId(1);
		admin.setfName("raju");
		admin.setlName("vinod");
		admin.setEmail("raju@gmail.com");
		admin.setuName("raju1");
		admin.setPass("vinod");
		admin.setPhoneNo(9876543210l);

		admins.add(admin);
		return admins;

	}
}
