package com.capg55.creditcardsystem.controller;



import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.capg55.creditcardsystem.model.CardHolder;
import com.capg55.creditcardsystem.model.CreditCard;
import com.capg55.creditcardsystem.model.Customer;
import com.capg55.creditcardsystem.repository.CardHolderRepository;

@SpringBootTest
//@TestMethodOrder(OrderAnnotation.class)

class CardHolderTests {
	
	@Autowired
	CardHolderRepository cardholderRepo ;

	@Test
	@Order(1)
	 public void testPostAndUpdate() {
		
		
		CardHolder ch = new CardHolder();
		ch.setCardNumber(33333333);
		
		 LocalDate fromdate
         = LocalDate.parse("2021-12-27");
		 
		ch.setFromDate(fromdate);
		
		 LocalDate todate
         = LocalDate.parse("2031-12-27");
		 
		ch.setToDate(todate);
		
		ch.setName("Siva");
		
		Customer c = new Customer();
		
		c.setCustId(11111);

		
	   ch.setCustomer(c);
	   
	   CreditCard cc = new CreditCard();
	   
	   cc.setCreditCardId(222222);

	   
	   ch.setCreditcard(cc);
		
		cardholderRepo.save(ch);
		
		
		
		System.out.println("Testcase for post and update is sucessfull .Check the DataBase");
	}
		
		////////////////////////////////////////////////////////////////////////////////////////////////////////////
		@Test
		@Order(3)
		public void testRetriveByCardNumber() {
		
        System.out.println(cardholderRepo.findById(11111111L).get());
		System.out.println("Testcase for get is sucessfull.The Data is shown above.");
		
		}
		
		/////////////////////////////////////////////////////////////////////////////////////////////////////////////
	    @Test
	    @Order(4)
	   public void testDelete() {
		   
		   cardholderRepo.deleteById(33333333L);
		   System.out.println("Testcase for delete is sucessfull.Check the Database");
		   
	   }
	    
	    /////////////////////////////////////////////////////////////////////////////////////////////////////////////
	    @Test
	    @Order(2)
	    public void testRetriveAll() {
	    	List<CardHolder> list = cardholderRepo.findAll();
	    	System.out.println(list);
	    	
	    	System.out.println();
	    	System.out.println();
	    	System.out.println("RetriveAll is sucessfull .Data's are given above");
	   }
		
		
	}

	

