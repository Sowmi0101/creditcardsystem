package com.capg55.creditcardsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CreditcardsystemApplicationTests {

	//@Test
	void contextLoads() {
	}

}
