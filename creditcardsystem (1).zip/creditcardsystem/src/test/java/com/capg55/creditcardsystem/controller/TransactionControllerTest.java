
package com.capg55.creditcardsystem.controller;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.capg55.creditcardsystem.model.Transaction;
import com.capg55.creditcardsystem.service.TransactionService;

@ExtendWith(MockitoExtension.class)
public class TransactionControllerTest {
	@InjectMocks
	TransactionController transactionController;

	@Mock
	TransactionService transactionService;

	@SuppressWarnings("unchecked")
	@Test
	void getAllTransactionTest() {
		List<Transaction> transaction = (List<Transaction>) createTransactionEntityMockData();
		when(transactionService.getAllTransactions()).thenReturn((ArrayList<Transaction>) transaction);

		List<Transaction> transactionList = transactionService.getAllTransactions();

		assert (transaction.size() == transactionList.size());
	}

	@Test
	void getTransactionbyCardIdTest() {

		int id = 1;
		Transaction transaction = createTransactionEntityMockData();
		ResponseEntity<Transaction> msg = new ResponseEntity<>(transaction, HttpStatus.OK);
		when(transactionService.getTransactionbyCardId(id)).thenReturn(transaction);

		ResponseEntity<Transaction> tran = transactionController.getTransactionById(id);

		assert (tran.equals(msg));
	}

	@SuppressWarnings("unused")
	private List<Transaction> createTransactionsEntityMockData() {
		List<Transaction> transactions = new ArrayList<>();

		Transaction transaction = new Transaction();
		transaction.setTransactionId(23);
		transaction.setTransactionDate(null);
		transaction.setStatus("Pending");
		transaction.setAmount(10000);

		transactions.add(transaction);
		return transactions;
	}

	private Transaction createTransactionEntityMockData() {
		Transaction transaction = new Transaction();
		transaction.setTransactionId(23);
		transaction.setTransactionDate(null);
		transaction.setStatus("Pending");
		transaction.setAmount(10000);

		return transaction;
	}
}
