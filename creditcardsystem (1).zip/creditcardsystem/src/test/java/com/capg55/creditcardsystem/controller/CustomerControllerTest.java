package com.capg55.creditcardsystem.controller;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.capg55.creditcardsystem.model.Customer;
import com.capg55.creditcardsystem.service.CustomerService;


@ExtendWith(MockitoExtension.class)
public class CustomerControllerTest {
	
	@InjectMocks
	CustomerController customerController;


	@Mock
	CustomerService customerService;


	@Test
	void getAllCustomersTest() {
		List<Customer> customer = createCustomersEntityMockData();
		when(customerService.getAllCustomers()).thenReturn(customer);

		List<Customer> customerList = customerService.getAllCustomers();

		assert (customer.size() == customerList.size());
	}
	
	@Test
	void getCustomerbyIdTest() {
		
		int id = 1;
		Customer customer = createCustomerEntityMockData();
		ResponseEntity<Customer> msg = new ResponseEntity<>(customer,HttpStatus.OK);
		when(customerService.getCustomerById(id)).thenReturn(customer);

		ResponseEntity<Customer> cust = customerController.getCustomerById(id);
		
		assert(cust.equals(msg));
	}
	
	@Test
	void saveCustomerTest() {
		
		Customer customer = createCustomerEntityMockData();
		ResponseEntity<String> msg = new ResponseEntity<String>("Customer added successfully: "+customer.getCustId(), HttpStatus.OK);
		
		when(customerService.saveCustomer(customer)).thenReturn(customer);
		
		ResponseEntity<String> customerInfo = customerController.addCustomer(customer);
		assert(customerInfo.equals(msg));
		
		
	}
		

	private List<Customer> createCustomersEntityMockData() {
		List<Customer> customers = new ArrayList<>();

		Customer customer = new Customer();
		customer.setCustId(1);
		customer.setfName("raju");
		customer.setlName("vinod");
		customer.setPhoneNo(985746258);
		customer.setEmail("raju@gmail.com");
		customer.setState("AP");
		customer.setGender("M");

		customers.add(customer);
		return customers;
	}
	
	private Customer createCustomerEntityMockData() {

		Customer customer = new Customer();
		customer.setCustId(6);
		customer.setfName("raju");
		customer.setlName("vinod");
		customer.setPhoneNo(985746258);
		customer.setEmail("raju@gmail.com");
		customer.setState("AP");
		customer.setGender("M");
		
		return customer;
	}

}
