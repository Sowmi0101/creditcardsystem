	package com.capg55.creditcardsystem.controller;

import static org.mockito.Mockito.when;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.doNothing;


import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.capg55.creditcardsystem.model.CreditCard;
import com.capg55.creditcardsystem.service.CreditCardService;

public class CreditCardControllerTest {
	
	@InjectMocks
	CreditCardController creditcardController;


	@Mock
	CreditCardService creditcardService;


	@Test
	void getAllCreditCardTest() {
		List<CreditCard> creditcards = createCreditCardsMockData();
		when(creditcardService.getAllCreditCardList()).thenReturn(creditcards);

		List<CreditCard> creditcardList = creditcardService.getAllCreditCardList();

		assert (creditcards.size() == creditcardList.size());
	}
	
	@Test
	void getCreditCardbyIdTest() {
		
		int id = 6;
		CreditCard creditcard = createCreditCardEntityMockData();

		when(creditcardService.getCreditCardById(id)).thenReturn(creditcard);

		CreditCard creditCard = creditcardController.getCreditCardById(id);
		
		assert(creditCard.equals(creditcard));
	}
	
	@Test
	void saveCreditCardTest() {
		
		CreditCard creditcard = createCreditCardEntityMockData();
		ResponseEntity<String> msg = new ResponseEntity<String>("CreditCard added successfully: "+creditcard.getCreditCardId(), HttpStatus.OK);
		
		when(creditcardService.saveCreditCard(creditcard)).thenReturn(creditcard);
		
		ResponseEntity<String> creditcardInfo = creditcardController.addCreditCard(creditcard);
		assert(creditcardInfo.equals(msg));
		
		
	}
		

	private List<CreditCard> createCreditCardsMockData() {
		List<CreditCard> creditcards = new ArrayList<>();

		CreditCard creditcard = new CreditCard();
		creditcard.setCreditCardId(7);
		creditcard.setType("Gold");
		creditcard.setJoiningFees(50000);
		creditcard.setAnnualFees(90000);
		creditcard.setMoneyLimit(1000000);
		creditcard.setBankName("SBI");

		creditcards.add(creditcard);
		return creditcards;
	}
	
	private CreditCard createCreditCardEntityMockData() {

		CreditCard creditcard = new CreditCard();
		creditcard.setCreditCardId(6);
		creditcard.setType("Platinum");
		creditcard.setJoiningFees(4000);
		creditcard.setAnnualFees(40000);
		creditcard.setMoneyLimit(400000);
		creditcard.setBankName("HDFC");
		
		return creditcard;
	}


}