package com.capg55.creditcardsystem.service;

import java.util.ArrayList;

import com.capg55.creditcardsystem.model.Admin;

public interface AdminService {


	ArrayList<Admin> getAllAdmins();

	Admin saveAdmin(Admin admin);

	Admin getAdminById(int adminId);


}
