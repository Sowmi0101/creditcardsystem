package com.capg55.creditcardsystem.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;

@Entity
public class Admin {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int adminId;
	
	@NotNull(message = "FirstName cannot be empty")
	private String fName;
	@NotNull(message = "LastName cannot be empty")
	private String lName;
	@NotNull(message = "UserName cannot be empty")
	private String uName;
	@NotNull(message = "Password cannot be empty")
	private String pass;
	@NotNull(message = "PhoneNo cannot be empty")
	private long phoneNo;
	@Email(message = "Email cannot be empty")
	private String email;
	
	public Admin() {
		super();
	}

	public Admin(int adminId, String fName, String lName, String uName, String pass, long phoneNo, String email) {
		super();
		this.adminId = adminId;
		this.fName = fName;
		this.lName = lName;
		this.uName = uName;
		this.pass = pass;
		this.phoneNo = phoneNo;
		this.email = email;
	}

	public int getAdminId() {
		return adminId;
	}

	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}

	public String getfName() {
		return fName;
	}

	public void setfName(String fName) {
		this.fName = fName;
	}

	public String getlName() {
		return lName;
	}

	public void setlName(String lName) {
		this.lName = lName;
	}

	public String getuName() {
		return uName;
	}

	public void setuName(String uName) {
		this.uName = uName;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public long getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "Admin [adminId=" + adminId + ", fName=" + fName + ", lName=" + lName + ", uName=" + uName + ", pass="
				+ pass + ", phoneNo=" + phoneNo + ", email=" + email + "]";
	}
	
	
	
	

}
