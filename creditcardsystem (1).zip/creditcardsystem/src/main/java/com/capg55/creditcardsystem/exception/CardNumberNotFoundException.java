package com.capg55.creditcardsystem.exception;

public class CardNumberNotFoundException extends RuntimeException{
	
	private String message;
	
	 public CardNumberNotFoundException() {}
	
	public CardNumberNotFoundException(String msg)
	{
		super(msg);
		this.message=msg;
	}
	

}
