package com.capg55.creditcardsystem.repository;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.capg55.creditcardsystem.model.Customer;


@Repository
public interface CustomerRepository extends CrudRepository<Customer,Integer>{

	Optional<Customer> findById(int custId);

	Optional<Customer> findByfName(String getfName);

}
