package com.capg55.creditcardsystem.service;

import java.util.List;

import com.capg55.creditcardsystem.model.Customer;

public interface CustomerService {

	Customer getCustomerById(int custId);

	Customer saveCustomer(Customer customer);

	List<Customer> getAllCustomers();

	Customer updateCustomer(int custId, Customer customer);

	void deleteCustomerById(int custId);

}
