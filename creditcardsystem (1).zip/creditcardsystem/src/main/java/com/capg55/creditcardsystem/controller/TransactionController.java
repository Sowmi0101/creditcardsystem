package com.capg55.creditcardsystem.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.capg55.creditcardsystem.model.Transaction;
import com.capg55.creditcardsystem.service.TransactionService;

@RestController
@RequestMapping(path = "/transaction")
public class TransactionController {
	
	@Autowired
	private TransactionService transactionService;
	
	
	@PostMapping("/addTransaction")
	public ResponseEntity<String> addTransaction(@RequestBody Transaction transaction) {
		transactionService.saveTransaction(transaction);
		return new ResponseEntity<String>("Transaction added successfully: "+transaction.getTransactionId(), HttpStatus.OK);
	}
	
	@GetMapping("/getTransactionById/{tranId}")
	public ResponseEntity<Transaction> getTransactionById(@PathVariable int tranId) {
		Transaction transaction = null;
		ResponseEntity<Transaction> tran = null;
		try {
			transaction = transactionService.getTransactionbyId(tranId);
			if(transaction == null) {
				
				tran = new ResponseEntity<>(transaction,HttpStatus.NOT_FOUND);
			}
			else {
				tran = new ResponseEntity<>(transaction,HttpStatus.OK);
			}
		} catch (Exception e) {
			tran = new ResponseEntity<>(transaction,HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return tran;
	}
	
	@GetMapping("/getAllTransaction")
	public ArrayList<Transaction> getAllTransaction(){
		return (ArrayList<Transaction>) transactionService.getAllTransactions();
	}
	
	
	@GetMapping("/getTransactionbByCardId/{cardId}")
	public ResponseEntity<Transaction> getTransactionByCardId(@PathVariable int cardId) {
		Transaction transaction = null;
		ResponseEntity<Transaction> tran = null;
		try {
			transaction = transactionService.getTransactionbyCardId(cardId);
			if(transaction == null) {
				
				tran = new ResponseEntity<>(transaction,HttpStatus.NOT_FOUND);
			}
			else {
				tran = new ResponseEntity<>(transaction,HttpStatus.OK);
			}
		} catch (Exception e) {
			tran = new ResponseEntity<>(transaction,HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return tran;
	}
	
	@GetMapping("/getTransactionByCustId/{custId}")
	public ResponseEntity<Transaction> getTransactionByCustId(@PathVariable int custId) {
		Transaction transaction = null;
		ResponseEntity<Transaction> tran = null;
		try {
			transaction = transactionService.getTransactionbyCustId(custId);
			if(transaction == null) {
				
				tran = new ResponseEntity<>(transaction,HttpStatus.NOT_FOUND);
			}
			else {
				tran = new ResponseEntity<>(transaction,HttpStatus.OK);
			}
		} catch (Exception e) {
			tran = new ResponseEntity<>(transaction,HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return tran;
	}
	

}
