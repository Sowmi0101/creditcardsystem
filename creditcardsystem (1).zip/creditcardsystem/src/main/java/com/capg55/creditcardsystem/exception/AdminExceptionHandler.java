package com.capg55.creditcardsystem.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class AdminExceptionHandler {
	
	@ExceptionHandler(value=AdminNotFoundException.class)
	public ResponseEntity<Object> AdminNotFoundExceptionHandler(AdminNotFoundException ex){
		return new ResponseEntity<Object>("Admin not found",HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(value=DuplicateAdminException.class)
	public ResponseEntity<Object> DuplicationExceptionHandler(DuplicateAdminException ex){
		return new ResponseEntity<Object>("Duplicate Admin found",HttpStatus.BAD_REQUEST);
	}

}
