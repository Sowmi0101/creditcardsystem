package com.capg55.creditcardsystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capg55.creditcardsystem.model.CardHolder;
import com.capg55.creditcardsystem.service.CardHolderService;







@RestController //(applied to class to mark it as request handler)
@RequestMapping(path = "/cardHolder") //(used to map HTTP requests to handler methods of MVC and restController)


public class CardHolderController {
	
	@Autowired(required=true) //(automatically injects the dependent beans into the associated class
	CardHolderService cardHolderService;
	
	@CrossOrigin(origins = "*") //(to avoid cross origin error while connecting with front end)
	@RequestMapping(value="/getAllCardHolder",method=RequestMethod.GET)
	public List<CardHolder> getAllCardHolder()
	{
		return  cardHolderService.getAllCardHolder();
	}
	
	@CrossOrigin(origins = "*") 
	@RequestMapping(value="/addCardHolder",method=RequestMethod.POST)
	public CardHolder addCardHolder( @RequestBody  CardHolder e) throws Exception
	{
	    return cardHolderService.addCardHolder(e);
		
	}
	
	
	@CrossOrigin(origins = "*")
	@RequestMapping(value="/updateCardHolder/{cardNumber}",method=RequestMethod.PUT)
	public CardHolder updateCardHolder(@PathVariable long cardNumber,@RequestBody CardHolder e)//(method parameter should be bound to URI template variable)
	{
		return cardHolderService.updateCardHolder(cardNumber,e);
	}
	

	@CrossOrigin(origins = "*")
	@RequestMapping(value="/deleteCardHolder/{cardNumber}",method=RequestMethod.DELETE)
	public void  deleteCardHolder(@PathVariable long cardNumber) 
	{
		cardHolderService.deleteCardHolder(cardNumber);
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////////
	
	
	@CrossOrigin(origins = "*")
	@RequestMapping(value="/searchCardHolderBycardNumber/{cardNumber}",method=RequestMethod.GET)
	public List<CardHolder> searchCardHolderBycardNumber(@PathVariable long cardNumber)
	{
		return cardHolderService.searchCardHolderBycardNumber(cardNumber);
	}
	
	

}
