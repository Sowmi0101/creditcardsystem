package com.capg55.creditcardsystem.exception;

public class DuplicateCustomerException extends RuntimeException {

}
