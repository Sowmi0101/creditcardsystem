package com.capg55.creditcardsystem.service;

import java.util.ArrayList;

import com.capg55.creditcardsystem.model.Transaction;

public interface TransactionService {

	Transaction getTransactionbyId(int tranId);

	ArrayList<Transaction> getAllTransactions();

	void saveTransaction(Transaction transaction);

	Transaction getTransactionbyCardId(int cardId);

	Transaction getTransactionbyCustId(int custId);

}
