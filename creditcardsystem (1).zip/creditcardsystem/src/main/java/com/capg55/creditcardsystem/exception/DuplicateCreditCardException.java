package com.capg55.creditcardsystem.exception;

public class DuplicateCreditCardException extends RuntimeException {

}
