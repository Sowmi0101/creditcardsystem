package com.capg55.creditcardsystem.exception;

public class AdminNotFoundException extends RuntimeException {

}
