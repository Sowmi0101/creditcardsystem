package com.capg55.creditcardsystem.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;



@Entity

public class CardHolder {

	@Id
	public long cardNumber;
	
	@NotNull(message="This field should not be empty")
	public LocalDate fromDate;
	
	@NotNull(message="This field should not be empty")
	public LocalDate toDate;
	
    @NotNull(message="This field should not be empty")
	@Pattern(regexp="[A-Z]{1}[a-z]*",message="Invalid name, First letter should be caps")
	public String name;
    
    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "cardHolder_customer_id")
	public Customer customer;

    
    @OneToOne(mappedBy = "cardHolder", cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(referencedColumnName = "creditcardId" ,name="creditcardId")
    public CreditCard creditCard;
    
    @OneToMany(mappedBy = "transactionId", cascade = CascadeType.ALL, orphanRemoval = true)
    public List<Transaction> transactions = new ArrayList<>();

	public CardHolder(long cardNumber, @NotNull(message = "This field should not be empty") LocalDate fromDate,
			@NotNull(message = "This field should not be empty") LocalDate toDate,
			@NotNull(message = "This field should not be empty") @Pattern(regexp = "[A-Z]{1}[a-z]*", message = "Invalid name, First letter should be caps") String name,
			Customer cust, CreditCard creditCard) {
		this.cardNumber = cardNumber;
		this.fromDate = fromDate;
		this.toDate = toDate;
		this.name = name;
		this.customer = cust;
		this.creditCard = creditCard;
	}

	public CardHolder() {
	}

	@Override
	public String toString() {
		return "CardHolder [cardNumber=" + cardNumber + ", fromDate=" + fromDate + ", toDate=" + toDate + ", name="
				+ name + ", cust=" + customer + ", creditcard=" + creditCard + "]";
	}

	public long getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(long cardNumber) {
		this.cardNumber = cardNumber;
	}

	public LocalDate getFromDate() {
		return fromDate;
	}

	public void setFromDate(LocalDate fromDate) {
		this.fromDate = fromDate;
	}

	public LocalDate getToDate() {
		return toDate;
	}

	public void setToDate(LocalDate toDate) {
		this.toDate = toDate;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public CreditCard getCreditcard() {
		return creditCard;
	}

	public void setCreditcard(CreditCard creditCard) {
		this.creditCard = creditCard;
	}
    
}