package com.capg55.creditcardsystem.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capg55.creditcardsystem.model.Customer;
import com.capg55.creditcardsystem.service.CustomerService;

@RestController
@RequestMapping(path = "/customer")
public class CustomerController {
	@Autowired
	private CustomerService customerService;

	@GetMapping("/getCustomerById/{custId}")
	public ResponseEntity<Customer> getCustomerById(@PathVariable int custId) {
		Customer customer = null;
		ResponseEntity<Customer> cust = null;
		try {
			customer = customerService.getCustomerById(custId);
			if (customer == null) {

				cust = new ResponseEntity<>(customer, HttpStatus.NOT_FOUND);
			} else {
				cust = new ResponseEntity<>(customer, HttpStatus.OK);
			}
		} catch (Exception e) {
			cust = new ResponseEntity<>(customer, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return cust;
	}

	@PostMapping("/addCustomer")
	public ResponseEntity<String> addCustomer(@RequestBody Customer cust) {
		customerService.saveCustomer(cust);
		return new ResponseEntity<String>("Customer added successfully: " + cust.getCustId(), HttpStatus.OK);
	}

	@DeleteMapping("/deleteCustomerById/{custId}")
	public ResponseEntity<String> deleteCustomer(@PathVariable int custId) {

		try {
			customerService.deleteCustomerById(custId);
			return new ResponseEntity<String>("Customer Deleted Successfully: "+custId, HttpStatus.OK);
			
		}catch (Exception e) {
			return new ResponseEntity<String>("Customer Deleted Successfully: "+custId, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		

	}

	@GetMapping("/getAllCustomers")
	public ArrayList<Customer> getAllCustomers() {
		return (ArrayList<Customer>) customerService.getAllCustomers();
	}

	@PutMapping("/updateCustomer/{custid}")
	public ResponseEntity<String> updateCustomer(@PathVariable int custid, @RequestBody Customer updatecustomer) {
		customerService.updateCustomer(custid, updatecustomer);
		return new ResponseEntity<String>("Customer Updated Successfully:" + custid, HttpStatus.OK);
	}

}
