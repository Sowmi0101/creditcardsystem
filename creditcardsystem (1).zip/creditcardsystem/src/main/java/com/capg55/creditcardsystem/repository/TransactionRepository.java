package com.capg55.creditcardsystem.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capg55.creditcardsystem.model.Transaction;

public interface TransactionRepository extends JpaRepository<Transaction ,Integer>{
	
	

}
