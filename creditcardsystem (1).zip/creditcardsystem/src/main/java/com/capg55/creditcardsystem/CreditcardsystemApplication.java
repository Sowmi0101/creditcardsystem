package com.capg55.creditcardsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CreditcardsystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(CreditcardsystemApplication.class, args);
	}

}
