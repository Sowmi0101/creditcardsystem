package com.capg55.creditcardsystem.exception;

public class CardNumberAlreadyExistsException extends RuntimeException {
	
	private String message;
	
	//public CardNumberAlreadyExistsException() {}
	  
    public  CardNumberAlreadyExistsException(String msg)
    {
        super(msg);
        this.message = msg;
    }
    
}
