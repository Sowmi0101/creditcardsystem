package com.capg55.creditcardsystem.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;

public class TransactionExceptionHandler {

	
	@ExceptionHandler(value=TransactionNotFoundException.class)
	public ResponseEntity<Object> TransactionNotFoundExceptionHandler(TransactionNotFoundException ex){
		return new ResponseEntity<Object>("Transaction not Found",HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(value=DuplicateTransactionException.class)
	public ResponseEntity<Object> DuplicationExceptionHandler(DuplicateTransactionException ex){
		return new ResponseEntity<Object>("Duplicate Transaction Found",HttpStatus.BAD_REQUEST);
	}
}
