package com.capg55.creditcardsystem.service;

import java.util.List;
import com.capg55.creditcardsystem.model.CreditCard;

public interface CreditCardService {
	
	CreditCard getCreditCardById(int creditcardId);

	void saveCreditCard(CreditCard creditcard);

	void deleteCreditCardId(int creditcardid);

	List<CreditCard> getAllCreditCardList();

	void updateCreditCard(int creditcardId, CreditCard creditcard );

	


}
