package com.capg55.creditcardsystem.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;



@Entity
public class CreditCard {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int creditCardId;
	@NotNull(message = "CreditCard Type cannot be empty")
	private String type;
	@NotNull(message = "JoiningFees cannot be empty")
	private int joiningFees;
	@NotNull(message = "AnnualFees cannot be empty")
	private int annualFees;
	@NotNull(message = "MoneyLimit cannot be empty")
	private int moneyLimit;
	@NotNull(message = "BankName cannot be empty")
	private String bankName;
	
	@JsonIgnore
	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	private CardHolder cardHolder;

	public CreditCard() {
		super();
	}

	public CreditCard(int creditCardId, String type, int joiningFees, int annualFees, int moneyLimit, String bankName) {
		super();
		this.creditCardId = creditCardId;
		this.type = type;
		this.joiningFees = joiningFees;
		this.annualFees = annualFees;
		this.moneyLimit = moneyLimit;
		this.bankName = bankName;
	}

	public int getCreditCardId() {
		return creditCardId;
	}

	public void setCreditCardId(int creditCardId) {
		this.creditCardId = creditCardId;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getJoiningFees() {
		return joiningFees;
	}

	public void setJoiningFees(int joiningFees) {
		this.joiningFees = joiningFees;
	}

	public int getAnnualFees() {
		return annualFees;
	}

	public void setAnnualFees(int annualFees) {
		this.annualFees = annualFees;
	}

	public int getMoneyLimit() {
		return moneyLimit;
	}

	public void setMoneyLimit(int moneyLimit) {
		this.moneyLimit = moneyLimit;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	@Override
	public String toString() {
		return "CreditCard [creditCardId=" + creditCardId + ", type=" + type + ", joiningFees=" + joiningFees
				+ ", annualFees=" + annualFees + ", moneyLimit=" + moneyLimit + ", bankName=" + bankName + "]";
	}
	
	
	

}
