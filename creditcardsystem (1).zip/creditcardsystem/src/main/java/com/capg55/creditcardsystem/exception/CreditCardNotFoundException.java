package com.capg55.creditcardsystem.exception;

public class CreditCardNotFoundException extends RuntimeException {

}
