package com.capg55.creditcardsystem.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg55.creditcardsystem.exception.CreditCardNotFoundException;
import com.capg55.creditcardsystem.exception.DuplicateCreditCardException;
import com.capg55.creditcardsystem.model.CreditCard;
import com.capg55.creditcardsystem.repository.CreditCardRepository;
import com.capg55.creditcardsystem.service.CreditCardService;

@Service
public class CreditCardServiceImpl implements CreditCardService {
	@Autowired
	private CreditCardRepository creditcardRepository;

	@Override
	public CreditCard getCreditCardById(int creditcardId) {
		Optional<CreditCard> opt = creditcardRepository.findById(creditcardId);
		if (!opt.isPresent()) {
			throw new CreditCardNotFoundException();
		}
		return opt.get();
	}

	@Override
	public void saveCreditCard(CreditCard creditcard) {
		Optional<CreditCard> opt = creditcardRepository.findById(creditcard.getCreditCardId());
		if (opt.isPresent()) {
			throw new DuplicateCreditCardException();
		}
		creditcardRepository.save(creditcard);
	}

	@Override
	public void deleteCreditCardId(int creditcardid) {
		Optional<CreditCard> opt = creditcardRepository.findById(creditcardid);
		if (!opt.isPresent()) {
			throw new CreditCardNotFoundException();
		}
		creditcardRepository.deleteById(creditcardid);

	}

	@Override
	public List<CreditCard> getAllCreditCardList() {
		return (List<CreditCard>) creditcardRepository.findAll();
	}

	@Override
	public void updateCreditCard(int creditcardId, CreditCard creditcard) {
		deleteCreditCardId(creditcardId);
		saveCreditCard(creditcard);

	}

}
