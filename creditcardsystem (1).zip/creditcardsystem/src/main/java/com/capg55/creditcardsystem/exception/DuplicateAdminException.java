package com.capg55.creditcardsystem.exception;

public class DuplicateAdminException extends RuntimeException {

}
