package com.capg55.creditcardsystem.exception;

public class TransactionNotFoundException extends RuntimeException{

}
