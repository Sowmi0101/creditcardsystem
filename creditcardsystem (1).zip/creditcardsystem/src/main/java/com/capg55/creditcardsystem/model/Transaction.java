package com.capg55.creditcardsystem.model;



import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.springframework.data.annotation.CreatedDate;

@Entity
public class Transaction {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int transactionId;

	@CreatedDate
	@GeneratedValue(strategy = GenerationType.AUTO)
	private LocalDate transactionDate;

	private String status;
	private double amount;

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(referencedColumnName = "cardNumber", name = "cardNumber")
	public CardHolder cardHolder;

	public Transaction() {
		super();
	}

	public Transaction(int transactionId, LocalDate transactionDate, String status, double amount, CardHolder CH) {
		super();
		this.transactionId = transactionId;
		this.transactionDate = transactionDate;
		this.status = status;
		this.amount = amount;
		this.cardHolder = CH;
	}

	public int getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public LocalDate getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(LocalDate transactionDate) {
		this.transactionDate = transactionDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public CardHolder getCH() {
		return cardHolder;
	}

	public void setCH(CardHolder cH) {
		cardHolder = cH;
	}

	@Override
	public String toString() {
		return "Transaction [transactionId=" + transactionId + ", transactionDate=" + transactionDate + ", status="
				+ status + ", amount=" + amount + ", CH=" + cardHolder + "]";
	}

}
