package com.capg55.creditcardsystem.service;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg55.creditcardsystem.exception.CardNumberAlreadyExistsException;
import com.capg55.creditcardsystem.exception.CardNumberNotFoundException;
import com.capg55.creditcardsystem.model.CardHolder;
import com.capg55.creditcardsystem.repository.CardHolderRepository;

@Service
public class CardHolderService {

	@Autowired(required = true)
	CardHolderRepository repository;

	public List<CardHolder> getAllCardHolder() {
		return repository.findAll();
	}

	public CardHolder addCardHolder(CardHolder e) throws Exception {
		if (!(e.cardNumber >= 10000000 && e.cardNumber <= 99999999)) {
			throw new Exception("Invalid cardNumber, cardNumber should be 8 digit only");
		}

		CardHolder exisitingCardHolder = repository.findById(e.getCardNumber()).orElse(null);
		if (exisitingCardHolder == null) {

			return repository.save(e);

		} else {
			throw new CardNumberAlreadyExistsException("CardHolder already exist with this cardNumber!!");
		}

	}

	public CardHolder updateCardHolder(long cardNumber, CardHolder e) {
		CardHolder e1 = repository.findById(cardNumber).get();
		if (e1 != null) {
			e1.setCardNumber(e.getCardNumber());
			e1.setFromDate(e.getFromDate());
			e1.setToDate(e.getToDate());
			e1.setName(e.getName());

			return repository.save(e1);
		}

		else
			return e1;
	}

	public void deleteCardHolder(long cardNumber) {
		try {

			CardHolder e1 = repository.findById(cardNumber).get();

			if (e1 == null)
				throw new NoSuchElementException();

			else {
				repository.delete(e1);
			}
		} catch (NoSuchElementException e) {
			throw new CardNumberNotFoundException(
					"The cardNumber you entered is not there in table or foreign key value not present in that table .So deliton is not possible");

		}

	}

	public List<CardHolder> searchCardHolderBycardNumber(long cardNumber)

	{
		try {
			CardHolder e1 = repository.findById(cardNumber).get();

			if (e1 == null)
				throw new NoSuchElementException();

		} catch (NoSuchElementException e) {
			throw new CardNumberNotFoundException(
					"The cardNumber you entered is not there in table or foreign key not present in that table .So retriving is not possible");
		}

		return (repository.searchCardHolderBycardNumber(cardNumber));
	}
}
