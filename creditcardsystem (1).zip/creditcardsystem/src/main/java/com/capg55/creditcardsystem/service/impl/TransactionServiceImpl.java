package com.capg55.creditcardsystem.service.impl;

import java.util.ArrayList;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg55.creditcardsystem.exception.DuplicateTransactionException;
import com.capg55.creditcardsystem.exception.TransactionNotFoundException;
import com.capg55.creditcardsystem.model.Transaction;
import com.capg55.creditcardsystem.repository.TransactionRepository;
import com.capg55.creditcardsystem.service.TransactionService;

@Service
public class TransactionServiceImpl implements TransactionService {

	@Autowired
	private TransactionRepository transactionRepository;

	@Override
	public Transaction getTransactionbyId(int tranId) {
		Optional<Transaction> opt = transactionRepository.findById(tranId);
		if (!opt.isPresent()) {
			throw new TransactionNotFoundException();
		}
		return opt.get();
	}

	@Override
	public ArrayList<Transaction> getAllTransactions() {
		return (ArrayList<Transaction>) transactionRepository.findAll();
	}

	@Override
	public void saveTransaction(Transaction transaction) {
		Optional<Transaction> opt = transactionRepository.findById(transaction.getTransactionId());
		if (opt.isPresent()) {
			throw new DuplicateTransactionException();
		}
		transactionRepository.save(transaction);
	}

	@Override
	public Transaction getTransactionbyCardId(int cardId) {
		Optional<Transaction> opt = transactionRepository.findById(cardId);
		if (!opt.isPresent()) {
			throw new TransactionNotFoundException();
		}
		return opt.get();
	}

	@Override
	public Transaction getTransactionbyCustId(int custId) {
		Optional<Transaction> opt = transactionRepository.findById(custId);
		if (!opt.isPresent()) {
			throw new TransactionNotFoundException();
		}
		return opt.get();
	}

}
