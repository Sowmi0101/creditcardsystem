package com.capg55.creditcardsystem.service.impl;

import java.util.ArrayList;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg55.creditcardsystem.exception.AdminNotFoundException;
import com.capg55.creditcardsystem.exception.DuplicateAdminException;
import com.capg55.creditcardsystem.model.Admin;
import com.capg55.creditcardsystem.repository.AdminRepository;
import com.capg55.creditcardsystem.service.AdminService;

@Service
public class AdminServiceImpl implements AdminService{
	
	@Autowired
	private AdminRepository adminRepository;

	@Override
	public Admin getAdminById(int adminId) {
		Optional<Admin> opt= adminRepository.findById(adminId);
		if(!opt.isPresent()) {
			throw new AdminNotFoundException();
		}
		return opt.get();
	}

	@Override
	public ArrayList<Admin> getAllAdmins() {
		return (ArrayList<Admin>) adminRepository.findAll();
	}

	@Override
	public Admin saveAdmin(Admin admin) {
		Optional<Admin> opt= adminRepository.findByfName(admin.getfName());
		if(opt.isPresent()) {
			throw new DuplicateAdminException();
		}
		return adminRepository.save(admin);
		
	}
	

}
