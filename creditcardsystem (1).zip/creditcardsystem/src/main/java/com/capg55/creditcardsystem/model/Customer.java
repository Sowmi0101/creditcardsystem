package com.capg55.creditcardsystem.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;

@Entity

public class Customer {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int custId;
	@NotNull(message = "FirstName should not be empty")
	private String fName;
	@NotNull(message = "LastName should not be empty")
	private String lName;
	@NotNull(message = "Phone number should not be empty")
	private long phoneNo;
	@Email(message = "Email should not be empty")
	private String email;
	@NotNull(message = "Please enter your state")
	private String state;
	private String gender;
	
	@OneToMany(mappedBy = "customer", cascade = CascadeType.ALL, orphanRemoval = true)
	private List<CardHolder> cardHolder = new ArrayList<>();
		
	public Customer() {
		super();
	}

	public Customer(int custId, String fName, String lName, long phoneNo, String email, String state, String gender) {
		super();
		this.custId = custId;
		this.fName = fName;
		this.lName = lName;
		this.phoneNo = phoneNo;
		this.email = email;
		this.state = state;
		this.gender = gender;
	}

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public String getfName() {
		return fName;
	}

	public void setfName(String fName) {
		this.fName = fName;
	}

	public String getlName() {
		return lName;
	}

	public void setlName(String lName) {
		this.lName = lName;
	}

	public long getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	@Override
	public String toString() {
		return "customer [custId=" + custId + ", fName=" + fName + ", lName=" + lName + ", phoneNo=" + phoneNo
				+ ", email=" + email + ", state=" + state + ", gender=" + gender + "]";
	}
	
	
	
	
	

}
