package com.capg55.creditcardsystem.repository;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.capg55.creditcardsystem.model.CreditCard;

@Repository
public interface CreditCardRepository extends CrudRepository<CreditCard,Integer>{

	Optional<CreditCard> findById(int creditcardId);

	Optional<CreditCard> findByType(String getType);
}
	


