package com.capg55.creditcardsystem.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class CreditCardExceptionHandler { 
	@ExceptionHandler(value=CreditCardNotFoundException.class)
	public ResponseEntity<Object> CreditCardNotFoundExceptionHandler(CreditCardNotFoundException ex){
		return new ResponseEntity<Object>("CreditCard not Found",HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(value=DuplicateCreditCardException.class)
	public ResponseEntity<Object> DuplicationExceptionHandler(DuplicateCreditCardException ex){
		return new ResponseEntity<Object>("Duplicate CreditCard Found",HttpStatus.BAD_REQUEST);
	}


}
