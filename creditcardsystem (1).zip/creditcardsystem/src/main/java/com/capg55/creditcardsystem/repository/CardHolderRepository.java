package com.capg55.creditcardsystem.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capg55.creditcardsystem.model.CardHolder;




@Repository

public interface CardHolderRepository extends JpaRepository<CardHolder ,Long> {

	@Query(value="select e from CardHolder e where e.cardNumber=?1") 
    public List<CardHolder> searchCardHolderBycardNumber(@Param("cardNumber")Long cardNumber);

	
  

}
