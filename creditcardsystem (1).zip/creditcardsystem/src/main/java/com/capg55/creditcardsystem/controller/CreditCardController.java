package com.capg55.creditcardsystem.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capg55.creditcardsystem.model.CreditCard;
import com.capg55.creditcardsystem.service.CreditCardService;

@RestController
@RequestMapping(path = "/creditCard")
public class CreditCardController {
    @Autowired   
	private CreditCardService creditCardService;
    

	@GetMapping("/getCreditCardById/{creditcardId}")
	public CreditCard getCreditCardById(@PathVariable int creditcardId) {
		return creditCardService.getCreditCardById(creditcardId);
	}
	
	@PostMapping("/addCreditCard")
	public ResponseEntity<String> addCreditCard(@RequestBody CreditCard creditcard) {
		creditCardService.saveCreditCard(creditcard);
		return new ResponseEntity<String>("CreditCard added successfully: "+creditcard.getCreditCardId(), HttpStatus.OK);
	}
	
	@DeleteMapping("/deleteCreditCard/{creditcardid}")
	public ResponseEntity<String> deleteCreditCard(@PathVariable int creditcardid) {
		creditCardService.deleteCreditCardId(creditcardid);
		return new ResponseEntity<String>("creditcard deleted successfully: "+creditcardid, HttpStatus.OK);
	}
	@GetMapping("/getCreditCardList")
	public ArrayList<CreditCard> getCreditCardList(){
		return (ArrayList<CreditCard>) creditCardService.getAllCreditCardList();
	}
	
	@PutMapping("/updateCreditCard/{creditcardid}")
	public ResponseEntity<String> updateCreditCard(@PathVariable int creditcardid,@RequestBody CreditCard updatecreditcard) {
		creditCardService.updateCreditCard(creditcardid, updatecreditcard);
		return new ResponseEntity<String>("creditcard updated successfully: "+creditcardid, HttpStatus.OK);
	}

}
