package com.capg55.creditcardsystem.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capg55.creditcardsystem.model.Admin;
import com.capg55.creditcardsystem.service.AdminService;


@RestController
@RequestMapping(path = "/admin")
public class AdminController {
	
	@Autowired
	private AdminService adminService;
	
	@GetMapping("/getAdminById/{adminId}")
	public ResponseEntity<Admin> getAdminById(@PathVariable int adminId) {
		
		Admin admin = null;
		ResponseEntity<Admin> admn = null;
		try {
			admin = adminService.getAdminById(adminId);
			if(admin != null) {
				admn = new ResponseEntity<>(admin,HttpStatus.OK);
			}
			else {
				admn = new ResponseEntity<>(admin,HttpStatus.NOT_FOUND);
			}
		} catch (Exception e) {
			admn = new ResponseEntity<>(admin,HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return admn;
	}
	
	@GetMapping("/getAllAdmins")
	public ArrayList<Admin> getAllAdmins(){
		return (ArrayList<Admin>) adminService.getAllAdmins();
	}
	
	@PostMapping("/addAdmin")
	public ResponseEntity<String> addAdmin(@RequestBody Admin admin) {
		adminService.saveAdmin(admin);
		return new ResponseEntity<String>("Admin added successfully:"+admin.getAdminId(), HttpStatus.OK);
	}

}
