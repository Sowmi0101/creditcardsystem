package com.capg55.creditcardsystem.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg55.creditcardsystem.exception.CustomerNotFoundException;
import com.capg55.creditcardsystem.exception.DuplicateCustomerException;
import com.capg55.creditcardsystem.model.Customer;
import com.capg55.creditcardsystem.repository.CustomerRepository;
import com.capg55.creditcardsystem.service.CustomerService;

@Service
public class CustomerServiceImpl implements CustomerService {
	@Autowired
	private CustomerRepository customerRepository;

	@Override
	public Customer getCustomerById(int custId) {
		Optional<Customer> opt = customerRepository.findById(custId);
		if (!opt.isPresent()) {
			throw new CustomerNotFoundException();
		}
		return opt.get();
	}

	@Override
	public Customer saveCustomer(Customer customer) {
		Optional<Customer> opt = customerRepository.findByfName(customer.getfName());
		if (opt.isPresent()) {
			throw new DuplicateCustomerException();
		}
		return customerRepository.save(customer);
	}

	@Override
	public void deleteCustomerById(int custid) {
		Optional<Customer> opt = customerRepository.findById(custid);
		if (!opt.isPresent()) {
			throw new CustomerNotFoundException();
		}
		customerRepository.deleteById(custid);

	}

	@Override
	public List<Customer> getAllCustomers() {
		return (List<Customer>) customerRepository.findAll();
	}

	@Override
	public Customer updateCustomer(int custId, Customer customer) {
		deleteCustomerById(custId);
		return saveCustomer(customer);

	}

}
