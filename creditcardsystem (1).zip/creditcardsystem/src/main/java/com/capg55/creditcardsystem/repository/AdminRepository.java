package com.capg55.creditcardsystem.repository;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.capg55.creditcardsystem.model.Admin;

public interface AdminRepository extends CrudRepository<Admin, Integer>{

	Optional<Admin> findByfName(String getfName);

}
