package com.capg55.creditcardsystem.exception;

public class CustomerNotFoundException extends RuntimeException {
	

}
